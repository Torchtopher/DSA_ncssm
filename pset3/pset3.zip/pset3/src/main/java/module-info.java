module edu.ncssm.briansea.pset3 {
    requires javafx.controls;
    requires javafx.fxml;

    opens edu.ncssm.briansea.pset3 to javafx.fxml;
    exports edu.ncssm.briansea.pset3;
}